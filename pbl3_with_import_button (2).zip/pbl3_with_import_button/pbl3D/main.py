"""
main.py
-------
Student Management System — PBL3 "beyond syllabus" project for
Python for Data Science (BE05000231).

Beyond-syllabus components:
    - Tkinter  : GUI / desktop application development (not in the PDS syllabus)
    - SQLite3  : persistent relational storage via db.py (not in the PDS syllabus)

Syllabus components used to tie it back to the subject:
    - Pandas   : builds a DataFrame from the SQLite records
    - Matplotlib: visualizes CGPA distribution / branch-wise counts

Run with:   python main.py
Requires:   Python 3.8+, pandas, matplotlib  (tkinter ships with standard Python)
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from db import StudentDB

BRANCHES = [
    "Computer Engineering",
    "Information Technology",
    "Electronics & Communication",
    "Mechanical Engineering",
    "Civil Engineering",
]

COLUMNS = ("roll_no", "name", "branch", "semester", "email", "phone", "cgpa")
HEADINGS = ("Roll No", "Name", "Branch", "Semester", "Email", "Phone", "CGPA")


class StudentManagementApp(tk.Tk):
    def about_project(self):
      messagebox.showinfo(
        "About Project",
        "Student Management System\n\n"
        "PBL Activity 3 - Python for Data Science\n\n"
        "Technologies Used:\n"
        "• Python\n"
        "• Tkinter - GUI\n"
        "• SQLite - Database\n"
        "• Pandas - CSV Import/Export\n"
        "• Matplotlib - Data Visualization\n\n"
        "Beyond Syllabus:\n"
        "Tkinter GUI and SQLite Database"
    )
    def __init__(self):
        super().__init__()
        self.title("Student Management System  —  PDS PBL3 (Beyond Syllabus: Tkinter + SQLite)")
        self.geometry("1000x620")
        self.minsize(900, 560)
        self.db = StudentDB()

        self._build_form()
        self._build_table()
        self._build_actions()
        self.refresh_table()

    # ---------------------------------------------------------------
    # FORM
    # ---------------------------------------------------------------
    def _build_form(self):
        frame = ttk.LabelFrame(self, text="Student Details")
        frame.pack(fill="x", padx=12, pady=10)

        self.vars = {
            "roll_no": tk.StringVar(),
            "name": tk.StringVar(),
            "branch": tk.StringVar(),
            "semester": tk.StringVar(),
            "email": tk.StringVar(),
            "phone": tk.StringVar(),
            "cgpa": tk.StringVar(),
        }

        def add_field(row, col, label, widget):
            ttk.Label(frame, text=label).grid(row=row, column=col * 2, sticky="w", padx=6, pady=6)
            widget.grid(row=row, column=col * 2 + 1, sticky="we", padx=6, pady=6)

        add_field(0, 0, "Roll No:", ttk.Entry(frame, textvariable=self.vars["roll_no"]))
        add_field(0, 1, "Name:", ttk.Entry(frame, textvariable=self.vars["name"]))
        add_field(0, 2, "Semester:", ttk.Spinbox(frame, from_=1, to=8, textvariable=self.vars["semester"], width=10))

        add_field(1, 0, "Branch:", ttk.Combobox(frame, textvariable=self.vars["branch"], values=BRANCHES, state="readonly"))
        add_field(1, 1, "Email:", ttk.Entry(frame, textvariable=self.vars["email"]))
        add_field(1, 2, "Phone:", ttk.Entry(frame, textvariable=self.vars["phone"]))

        add_field(2, 0, "CGPA (0-10):", ttk.Entry(frame, textvariable=self.vars["cgpa"]))

        for c in range(6):
            frame.grid_columnconfigure(c, weight=1)

        btns = ttk.Frame(frame)
        btns.grid(row=2, column=2, columnspan=4, sticky="e", padx=6, pady=6)
        ttk.Button(btns, text="Add", command=self.add_student).pack(side="left", padx=4)
        ttk.Button(btns, text="Update", command=self.update_student).pack(side="left", padx=4)
        ttk.Button(btns, text="Clear", command=self.clear_form).pack(side="left", padx=4)

    # ---------------------------------------------------------------
    # TABLE
    # ---------------------------------------------------------------
    def _build_table(self):
        frame = ttk.Frame(self)
        frame.pack(fill="both", expand=True, padx=12, pady=(0, 10))

        self.tree = ttk.Treeview(frame, columns=COLUMNS, show="headings", selectmode="browse")
        for col, heading in zip(COLUMNS, HEADINGS):
            self.tree.heading(col, text=heading)
            self.tree.column(col, width=120, anchor="center")
        self.tree.column("name", width=160, anchor="w")
        self.tree.column("email", width=170, anchor="w")

        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.bind("<<TreeviewSelect>>", self.on_row_select)

    # ---------------------------------------------------------------
    # SEARCH / DELETE / VISUALIZE / EXPORT
    # ---------------------------------------------------------------
    def _build_actions(self):
        frame = ttk.Frame(self)
        frame.pack(fill="x", padx=12, pady=(0, 12))

        ttk.Label(frame, text="Search:").pack(side="left")
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(frame, textvariable=self.search_var, width=30)
        search_entry.pack(side="left", padx=6)
        search_entry.bind("<KeyRelease>", lambda e: self.refresh_table())

        ttk.Button(frame, text="Delete Selected", command=self.delete_student).pack(side="left", padx=10)
        ttk.Button(frame, text="Visualize (Matplotlib)", command=self.visualize).pack(side="left", padx=4)
        ttk.Button(frame, text="Import from CSV (Pandas)", command=self.import_csv).pack(side="left", padx=4)
        ttk.Button(frame, text="Export to CSV (Pandas)", command=self.export_csv).pack(side="left", padx=4)

        ttk.Button(
             frame,
             text="About Project",
             command=self.about_project
        ).pack(side="left", padx=4) 

        self.status = ttk.Label(frame, text="", foreground="#555555")
        self.status.pack(side="right")

    # ---------------------------------------------------------------
    # DATA / FORM HELPERS
    # ---------------------------------------------------------------
    def refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        keyword = self.search_var.get().strip()
        rows = self.db.search_students(keyword) if keyword else self.db.get_all_students()
        for row in rows:
            self.tree.insert("", "end", values=row)
        self.status.config(text=f"{len(rows)} record(s)")

    def on_row_select(self, _event):
        selected = self.tree.selection()
        if not selected:
            return
        values = self.tree.item(selected[0], "values")
        for key, value in zip(COLUMNS, values):
            self.vars[key].set(value)

    def clear_form(self):
        for var in self.vars.values():
            var.set("")
        self.tree.selection_remove(self.tree.selection())

    def _read_form(self):
         data = {k: v.get().strip() for k, v in self.vars.items()}

    # Required fields
         if not data["roll_no"] or not data["name"] or not data["branch"]:
             raise ValueError("Roll No, Name and Branch are required.")

    # Semester validation
         if not data["semester"].isdigit() or not (1 <= int(data["semester"]) <= 8):
             raise ValueError("Semester must be a number between 1 and 8.")

    # CGPA validation
         try:
            cgpa = float(data["cgpa"])
         except ValueError:
            raise ValueError("CGPA must be a number.")

         if not (0 <= cgpa <= 10):
            raise ValueError("CGPA must be between 0 and 10.")
 
    # Email validation
         if data["email"] and ("@" not in data["email"] or "." not in data["email"]):
            raise ValueError("Enter a valid email address.")

    # Phone validation
         if data["phone"] and (not data["phone"].isdigit() or len(data["phone"]) != 10):
            raise ValueError("Phone number must contain exactly 10 digits.")

         return data
    # ---------------------------------------------------------------
    # CRUD ACTIONS
    # ---------------------------------------------------------------
    def add_student(self):
        try:
            d = self._read_form()
        except ValueError as e:
            messagebox.showerror("Invalid input", str(e))
            return
        try:
            self.db.add_student(d["roll_no"], d["name"], d["branch"], d["semester"], d["email"], d["phone"], d["cgpa"])
        except Exception as e:
            messagebox.showerror("Database error", f"Could not add student (duplicate Roll No?):\n{e}")
            return
        self.clear_form()
        self.refresh_table()

    def update_student(self):
        try:
            d = self._read_form()
        except ValueError as e:
            messagebox.showerror("Invalid input", str(e))
            return
        ok = self.db.update_student(d["roll_no"], d["name"], d["branch"], d["semester"], d["email"], d["phone"], d["cgpa"])
        if not ok:
            messagebox.showwarning("Not found", f"No student with Roll No '{d['roll_no']}' exists.")
            return
        self.clear_form()
        self.refresh_table()

    def delete_student(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Select a row", "Select a student in the table to delete.")
            return
        roll_no = self.tree.item(selected[0], "values")[0]
        if messagebox.askyesno("Confirm delete", f"Delete student '{roll_no}'?"):
            self.db.delete_student(roll_no)
            self.clear_form()
            self.refresh_table()

    # ---------------------------------------------------------------
    # SYLLABUS TIE-IN: Pandas export + Matplotlib visualization
    # ---------------------------------------------------------------
    def import_csv(self):
        import pandas as pd

        file_path = filedialog.askopenfilename(
            title="Select student CSV file",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not file_path:
            return

        required = {"roll_no", "name", "branch", "semester", "email", "phone", "cgpa"}
        try:
            df = pd.read_csv(file_path)
            missing = required - set(df.columns)
            if missing:
                messagebox.showerror(
                    "Invalid CSV",
                    "Missing column(s): " + ", ".join(sorted(missing)) +
                    "\n\nRequired columns: roll_no, name, branch, semester, email, phone, cgpa",
                )
                return

            added = 0
            skipped = 0
            errors = []

            for index, row in df.iterrows():
                try:
                    roll_no = str(row["roll_no"]).strip()
                    name = str(row["name"]).strip()
                    branch = str(row["branch"]).strip()
                    semester = str(int(row["semester"]))
                    email = "" if pd.isna(row["email"]) else str(row["email"]).strip()
                    phone = "" if pd.isna(row["phone"]) else str(row["phone"]).strip()
                    cgpa = float(row["cgpa"])

                    if not roll_no or not name or not branch:
                        raise ValueError("Roll No, Name and Branch are required")
                    if not (1 <= int(semester) <= 8):
                        raise ValueError("Semester must be between 1 and 8")
                    if not (0 <= cgpa <= 10):
                        raise ValueError("CGPA must be between 0 and 10")

                    if self.db.get_student(roll_no):
                        skipped += 1
                        continue

                    self.db.add_student(roll_no, name, branch, semester, email, phone, cgpa)
                    added += 1
                except Exception as e:
                    errors.append(f"Row {index + 2}: {e}")

            self.refresh_table()
            msg = f"Imported {added} student(s).\nSkipped {skipped} duplicate record(s)."
            if errors:
                msg += f"\nFailed {len(errors)} row(s)."
            messagebox.showinfo("CSV Import Complete", msg)
        except Exception as e:
            messagebox.showerror("Import error", f"Could not import CSV:\n{e}")

    def export_csv(self):
      import pandas as pd

      records = self.db.fetch_as_records()

      if not records:
        messagebox.showinfo(
            "No data",
            "There are no student records to export."
        )
        return

      df = pd.DataFrame(records)

      out_path = filedialog.asksaveasfilename(
        title="Save Student CSV",
        defaultextension=".csv",
        filetypes=[("CSV files", "*.csv")]
    )

      if not out_path:
        return

      try:
        df.to_csv(out_path, index=False)

        messagebox.showinfo(
             "Export Successful",
              f"Exported {len(df)} student record(s) successfully."
        )

      except Exception as e:
        messagebox.showerror(
            "Export Error",
            f"Could not export CSV:\n{e}"
        )

    def visualize(self):
        import pandas as pd
        import matplotlib.pyplot as plt

        records = self.db.fetch_as_records()
        if not records:
            messagebox.showinfo("No data", "Add some students first.")
            return
        df = pd.DataFrame(records)

        fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))

        axes[0].hist(df["cgpa"], bins=8, color="#8C7753", edgecolor="#331B0D")
        axes[0].set_title("CGPA Distribution")
        axes[0].set_xlabel("CGPA")
        axes[0].set_ylabel("Number of Students")

        branch_counts = df["branch"].value_counts()
        axes[1].bar(branch_counts.index, branch_counts.values, color="#331B0D")
        axes[1].set_title("Students per Branch")
        axes[1].tick_params(axis="x", rotation=30)

        fig.tight_layout()
        plt.show()


if __name__ == "__main__":
    app = StudentManagementApp()
    app.mainloop()
