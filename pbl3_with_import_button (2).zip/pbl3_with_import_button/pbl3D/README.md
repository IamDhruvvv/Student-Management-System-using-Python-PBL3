# Student Management System — PBL3 (Beyond Syllabus)

**Subject:** Python for Data Science (BE05000231)
**Activity:** PBL Activity 3 — Implementation of content beyond syllabus in lab practicals

## Why this is "beyond syllabus"

The Python for Data Science syllabus covers NumPy, Pandas, SciPy, Scikit-learn,
Matplotlib, and basic Seaborn — i.e. data handling, analysis, and plotting.
It does **not** cover:

- **GUI / desktop application development** — implemented here with **Tkinter**
  (`main.py`), giving the project a real, usable interface instead of a
  command-line script.
- **Persistent relational storage** — implemented here with **SQLite3**
  (`db.py`), so student records survive after the program closes, with proper
  CRUD (Create, Read, Update, Delete) operations and constraints (primary key
  on Roll No, CGPA range check).

To keep the project grounded in the subject, two in-syllabus tools are used on
top of this beyond-syllabus foundation:

- **Pandas** — builds a DataFrame from the SQLite table and exports it to CSV.
- **Matplotlib** — plots a CGPA distribution histogram and a branch-wise
  student count bar chart from the live data.

## Project structure

```
sms/
├── main.py      # Tkinter GUI — forms, table, search, buttons
├── db.py        # SQLite3 data layer — all CRUD operations
├── requirements.txt
└── README.md
```

## Features

- Add / Update / Delete student records (Roll No, Name, Branch, Semester,
  Email, Phone, CGPA)
- Live search across Roll No, Name, and Branch
- Table view of all records (Tkinter `ttk.Treeview`)
- Input validation (required fields, semester range, CGPA range)
- One-click **Export to CSV** via Pandas
- One-click **Visualize** (CGPA histogram + branch-wise bar chart) via
  Matplotlib

## How to run

```bash
pip install -r requirements.txt
python main.py
```

`tkinter` ships with the standard Python installer on Windows/macOS. On
Linux, install it separately if missing, e.g.:

```bash
sudo apt install python3-tk
```

A `students.db` SQLite file is created automatically in the same folder on
first run.

## Notes for the viva

- The data layer (`db.py`) is intentionally separated from the GUI so the
  CRUD logic can be explained and tested independently of the interface.
- CGPA is constrained to the 0–10 range at the database level (`CHECK`
  constraint) in addition to the form-level validation in the GUI.
- Roll No is the primary key, so duplicate entries are rejected by SQLite
  itself, not just by the UI.
