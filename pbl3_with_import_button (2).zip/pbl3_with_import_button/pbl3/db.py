"""
db.py
-----
Database layer for the Student Management System.

Beyond-syllabus note:
The Python for Data Science syllabus (NumPy, Pandas, SciPy, Scikit-learn,
Matplotlib, basic Seaborn) does not cover persistent storage or relational
databases. This module uses Python's built-in `sqlite3` module to give the
application real, persistent storage instead of an in-memory list — this is
the "beyond syllabus" component for the database side of the project.
"""

import sqlite3
from pathlib import Path

DB_FILE = Path(__file__).parent / "students.db"


class StudentDB:
    """Handles all database operations for student records."""

    def __init__(self, db_path: str = DB_FILE):
        self.db_path = str(db_path)
        self._create_table()

    def _connect(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _create_table(self):
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS students (
                    roll_no   TEXT PRIMARY KEY,
                    name      TEXT NOT NULL,
                    branch    TEXT NOT NULL,
                    semester  INTEGER NOT NULL,
                    email     TEXT,
                    phone     TEXT,
                    cgpa      REAL NOT NULL CHECK (cgpa >= 0 AND cgpa <= 10)
                )
                """
            )

    # ---------- CREATE ----------
    def add_student(self, roll_no, name, branch, semester, email, phone, cgpa):
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO students (roll_no, name, branch, semester, email, phone, cgpa)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (roll_no, name, branch, int(semester), email, phone, float(cgpa)),
            )

    # ---------- READ ----------
    def get_all_students(self):
        with self._connect() as conn:
            cur = conn.execute("SELECT * FROM students ORDER BY roll_no")
            return cur.fetchall()

    def get_student(self, roll_no):
        with self._connect() as conn:
            cur = conn.execute("SELECT * FROM students WHERE roll_no = ?", (roll_no,))
            return cur.fetchone()

    def search_students(self, keyword):
        kw = f"%{keyword}%"
        with self._connect() as conn:
            cur = conn.execute(
                """SELECT * FROM students
                   WHERE roll_no LIKE ? OR name LIKE ? OR branch LIKE ?
                   ORDER BY roll_no""",
                (kw, kw, kw),
            )
            return cur.fetchall()

    # ---------- UPDATE ----------
    def update_student(self, roll_no, name, branch, semester, email, phone, cgpa):
        with self._connect() as conn:
            cur = conn.execute(
                """UPDATE students
                   SET name = ?, branch = ?, semester = ?, email = ?, phone = ?, cgpa = ?
                   WHERE roll_no = ?""",
                (name, branch, int(semester), email, phone, float(cgpa), roll_no),
            )
            return cur.rowcount > 0

    # ---------- DELETE ----------
    def delete_student(self, roll_no):
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM students WHERE roll_no = ?", (roll_no,))
            return cur.rowcount > 0

    # ---------- Helpers for the Matplotlib/Pandas visualization (syllabus content) ----------
    def fetch_as_records(self):
        """Return rows as a list of dicts — convenient for building a Pandas DataFrame."""
        rows = self.get_all_students()
        cols = ["roll_no", "name", "branch", "semester", "email", "phone", "cgpa"]
        return [dict(zip(cols, row)) for row in rows]
